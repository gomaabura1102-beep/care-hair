import { getProductCareContent } from "@/data/product-care-content";
import { getAmazonReviewSnapshot } from "@/data/amazon-reviews";
import { products } from "@/data/products";
import type { ScoreKey } from "@/types/diagnosis";
import type { Product } from "@/types/product";

const brandOf = (name: string) => {
  if (name.includes("THE ANSWER")) return "THE ANSWER";
  if (name.includes("MEMEME")) return "MEMEME";
  if (name.includes("Sleek")) return "Sleek";
  if (name.includes("Qurap")) return "Qurap";
  if (name.includes("カウブランド")) return "カウブランド";
  if (name.includes("ミノン")) return "ミノン";
  if (name.includes("無印良品")) return "無印良品";
  if (name.includes("メルト")) return "メルト";
  return "プリュスオー";
};

const hairTypeMap = [
  ["fine", "細毛・軟毛"],
  ["normal", "普通毛"],
  ["coarse", "硬毛・剛毛"]
] as const;

const concernMap = [
  ["dry", "パサつき"],
  ["curly", "くせ毛・うねり"],
  ["frizz", "広がり"],
  ["volume", "ボリューム不足"],
  ["damage", "ダメージ"],
  ["scalp", "フケ・かゆみ"]
] as const;

const scentCategories = ["フローラル", "シトラス", "フルーティー", "ハーブ", "石けん", "無香料", "その他"] as const;

const priceNumber = (price: string) => Number(price.replace(/[^\d]/g, "")) || 0;

export function categorizeScent(scent: string) {
  if (scent.includes("フローラル") || scent.includes("ムスク")) return "フローラル";
  if (scent.includes("シトラス") || scent.includes("柑橘")) return "シトラス";
  if (scent.includes("フルーティー") || scent.includes("果実")) return "フルーティー";
  if (scent.includes("ハーブ") || scent.includes("グリーン")) return "ハーブ";
  if (scent.includes("石けん") || scent.includes("せっけん")) return "石けん";
  if (scent.includes("無香料") || scent.includes("香りがほとんど")) return "無香料";
  return "その他";
}

export function getProductInsight(product: Product) {
  const content = getProductCareContent(product);
  const hairTypes = hairTypeMap
    .filter(([key]) => (product.scores[key as ScoreKey] ?? 0) >= 4)
    .map(([, label]) => label);
  const concerns = concernMap
    .filter(([key]) => (product.scores[key as ScoreKey] ?? 0) >= 4)
    .map(([, label]) => label);
  const amazonReview = getAmazonReviewSnapshot(product.id);

  return {
    brand: brandOf(product.name),
    hairTypes: hairTypes.length ? hairTypes : ["普通毛"],
    concerns: concerns.length ? concerns : ["特になし"],
    scent: product.scent,
    scentCategory: categorizeScent(product.scent),
    finish: product.texture,
    washFeel: product.texture,
    reviewCount: amazonReview?.reviewCount ?? null,
    rating: amazonReview?.rating ?? null,
    amazonReview,
    priceValue: priceNumber(product.price),
    reviewHighlights: amazonReview ? [amazonReview.goodSummary, amazonReview.concernSummary] : []
  };
}

export const productsWithInsights = products.map((product) => ({
  ...product,
  insight: getProductInsight(product),
  careContent: getProductCareContent(product)
}));

export const filterOptions = {
  hairTypes: ["細毛・軟毛", "普通毛", "硬毛・剛毛"],
  concerns: ["パサつき", "くせ毛・うねり", "広がり", "ボリューム不足", "ダメージ", "フケ・かゆみ", "特になし"],
  scents: [...scentCategories],
  ratings: ["4.5以上", "4.0以上", "3.5以上"],
  brands: Array.from(new Set(products.map((product) => brandOf(product.name)))),
  priceRanges: [
    { label: "1,500円以下", min: 0, max: 1500 },
    { label: "1,501円〜1,700円", min: 1501, max: 1700 },
    { label: "1,701円〜2,000円", min: 1701, max: 2000 }
  ]
};

export const trendingProducts = productsWithInsights
  .filter((product) => ["the-answer-shampoo", "plus-eau-repair-shampoo", "qurap-wrapping-moist-shampoo", "mememe-smooth-boost-shampoo"].includes(product.id))
  .map((product, index) => ({
    product,
    label: ["口コミ急上昇", "今月人気", "高校生人気", "AIおすすめ"][index] ?? "注目"
  }));
